package com.capstore.util;

public enum OrderStatus 
{ 
    BeingPrepared, Ready, Shipped, Delivered; 
} 