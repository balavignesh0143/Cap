package com.capstore.util;

public enum Rating {
	Poor, Okay, Good, VeryGood, Excellent;
}