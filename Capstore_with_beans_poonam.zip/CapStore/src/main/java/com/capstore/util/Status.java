package com.capstore.util;

public enum Status {
	Active, Blocked
}