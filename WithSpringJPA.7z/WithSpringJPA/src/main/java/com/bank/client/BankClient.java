package com.bank.client;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bank.entities.Transaction;
import com.bank.service.BankService;
public class BankClient {


	public static void main(String[] args) {

		Scanner sc  = new Scanner(System.in);      
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		BankService bankService =  context.getBean("bankService",BankService.class);
		String press1;
		int c,balance;
		String choice,name,password,phoneNo;

		while(true)
		{
			System.out.println("***********************************");

			System.out.println("1. Create account");
			System.out.println("2. Show balance");
			System.out.println("3. Deposit balance");
			System.out.println("4. Withdraw money");
			System.out.println("5. Fund transfer");
			System.out.println("6. Mini Statement");
			System.out.println("7. Exit");
			System.out.println("\nEnter Your choice : ");
			press1 = sc.next();

			if(press1.matches("[a-z]*")||press1.matches("[A-Z]*")){	     
				System.out.println("Invalid Choice!!!");
				main(null);
			}
			switch (press1) {
			case "1":
				System.out.println("Welcome to UnsignedInteger Bank");
				do{
					System.out.println("Enter Your Name : ");
					name = sc.next();
					c =bankService.nameValidate(name);
				}while(c!=1);
				
				do{
					System.out.println("Enter Your Phone Number : ");
					phoneNo = sc.next();
					c = bankService.mobNoValidate(phoneNo);
				}while(c!=1);

				long phone = Long.parseLong(phoneNo);
				long accountNo = phone + 1;

				do{
					System.out.println("Enter Password : ");
					password = sc.next();
					c = bankService.passwordValidate(password);
				}while(c!=1);

				balance = 2000;
				boolean result =  bankService.createAccount(name,phoneNo,password,accountNo,balance);
				if(result){
					System.out.println("Account created successfully :-)\n Your Account No is : "+accountNo);
				}break;

			case "2":

				System.out.println("Enter Account Number : ");
				accountNo = sc.nextLong();
				System.out.println("Enter Password : ");
				password = sc.next();
				boolean b1= bankService.validateAccount(accountNo,password);
				if(b1){
					balance = bankService.showBalance(accountNo);
					if(balance!=0){
						System.out.println("Your Current Balance : "+balance);
					}
					else{
						System.out.println("Something went wrong, Please try again later :-)");
					}
				}else{
					System.out.println("Invalid Credantials :-(");
				}

				break;
				
			case "3":
				System.out.println("Enter Account Number : ");
				accountNo = sc.nextLong();
				System.out.println("Enter Password : ");
				password = sc.next();
				boolean b= bankService.validateAccount(accountNo,password);
				if(b)
				{
					System.out.println("Enter Amount for Deposite : ");
					int deposit = sc.nextInt();
					balance = bankService.depositAmount(accountNo,deposit);
					System.out.println("Amount Deposited Successfully :-)\n");
					System.out.println("Updated Balance : "+balance);
				}
				else{
					System.out.println("Invalid Credantials :-(");
				}
				break;
				
			case "4":

				System.out.println("Enter Account Number : ");
				accountNo = sc.nextLong();
				System.out.println("Enter Password : ");
				password = sc.next();
				b= bankService.validateAccount(accountNo,password);
				if(b){
					balance = bankService.showBalance(accountNo);
					System.out.println("Your Current Balance : "+balance);
					System.out.println("Enter Amount for Withdrawn : ");
					int withdraw = sc.nextInt();
					balance = bankService.withdrawAmount(accountNo,withdraw);
					if(balance>=0){
						System.out.println("Amount Withdrawn Successfully :-)\n");
						System.out.println("Updated Balance : "+balance);
					}
					else{
						System.out.println("Insufficient funds");
					}
				}


				else{
					System.out.println("Invalid Credantials :-(");
				}
				break;

			case "5":

				System.out.println("Enter Account Number : ");
				accountNo = sc.nextLong();
				System.out.println("Enter Password : ");
				password = sc.next();
				b= bankService.validateAccount(accountNo,password);
				if(b){
					System.out.println("\nEnter Account No to Transfer");
					long  accno = sc.nextLong();
					System.out.println("Enter Amount : ");
					int amount = sc.nextInt();
					boolean transfer = bankService.fundTransfer(accountNo, accno, amount);
					if(transfer){
						System.out.println("Transaction done Successfully :-)\n");
					}
					else{
						System.out.println("Something went wrong :-(");
					}
				}
				else{
					System.out.println("Invalid Credantials :-(");
				}

				break;
			case "6":
				System.out.println("Enter Account Number : ");
				accountNo = sc.nextLong();
				System.out.println("Enter Password : ");
				password = sc.next();
				b= bankService.validateAccount(accountNo,password);
				if(b){
					List<Transaction> trans=bankService.getTransaction(accountNo);

					System.out.println("----------Mini Statement----------\n");

					for(Transaction tran:trans){
						System.out.println(tran);
					}

				}
				else {
					System.out.println("Invalid Credantials :-(");
				}
				break;

			case "7": 
				System.out.println("Thank You for Using Our Services :-)");
				System.exit(0);
			}

		}

	}

}
