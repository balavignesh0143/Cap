package com.capgemini.capstore.service;

import org.springframework.web.bind.annotation.PathVariable;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.exceptions.CapStoreException;

public interface IPasswordOperation {

	boolean changePassword(long customerId, String oldPassword, String newPassword, Customer customer)
			throws CapStoreException;

	public boolean forgetPassword(@PathVariable long customerId, int customerQuestion, String customerAnswer,
			String newPassword, Customer customer) throws CapStoreException;

	long findByCustomerContactNo(String customerContactNo);

	boolean changePassword(long merchantId, String oldPassword, String newPassword, Merchant merchant)
			throws CapStoreException;

	boolean forgetPassword(long merchantId, int merchantQuestion, String merchantAnswer, String newPassword,
			Merchant merchant) throws CapStoreException;

	long findByMerchantContactNo(String merchantContactNo);
}
