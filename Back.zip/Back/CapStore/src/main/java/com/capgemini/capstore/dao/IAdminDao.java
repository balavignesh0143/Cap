package com.capgemini.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.capstore.beans.Admin;

public interface IAdminDao extends JpaRepository<Admin, Long> {

	@Query("from Admin where adminId=?1")
	Admin findByAdminId(long adminId);

}
