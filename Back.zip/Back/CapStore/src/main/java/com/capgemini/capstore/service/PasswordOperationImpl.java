package com.capgemini.capstore.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.dao.ICustomerDao;
import com.capgemini.capstore.dao.IMerchantDao;
import com.capgemini.capstore.exceptions.CapStoreException;
import com.capgemini.capstore.util.Decryption;
import com.capgemini.capstore.util.Encryption;
import com.capgemini.capstore.util.Status;

@Service
public class PasswordOperationImpl implements IPasswordOperation {

	@Autowired
	ICustomerDao customerDao;

	@Override
	public boolean changePasswordCustomer(long customerId, String oldPassword, String newPassword)
			throws CapStoreException {
		try {
			Optional<Customer> optional = customerDao.findById(customerId);
			if (optional.isPresent()) {
				if (Decryption.decrypt(optional.get().getCustomerPassword()).contains(oldPassword)) {
					 Customer customer = optional.get();
					customer.setCustomerId(optional.get().getCustomerId());
					customer.setCustomerName(optional.get().getCustomerName());
					customer.setCustomerPassword(Encryption.encrypt(newPassword));
					customer.setCustomerContactNo(optional.get().getCustomerContactNo());
					customer.setCustomerAddress(optional.get().getCustomerAddress());
					customer.setCustomerStatus(Status.ACTIVE);
					customerDao.save(customer);
					return true;
				} else {
					throw new CapStoreException("Please enter correct Old Password.");
				}
			} else {
				throw new CapStoreException("Account does not Exist.");
			}

		} catch (Exception e) {
			throw new CapStoreException("Please enter valid details :-(");
		}

	}

	@Override
	public boolean forgetPassword(long customerId, Integer customerQuestion, String customerAnswer, String newPassword
			) throws CapStoreException {
		try {
			Optional<Customer> optional = customerDao.findById(customerId);
			if (optional.isPresent()) {
				if (optional.get().getCustomerAnswer().contains(customerAnswer)
						&& optional.get().getCustomerQuestion() == customerQuestion) {
					Customer customer = optional.get();
					customer.setCustomerPassword(Encryption.encrypt(newPassword));
					customerDao.save(customer);
					System.out.println(customer);
					return true;
				} else {
					throw new CapStoreException("Please enter the correct answer for that question.");
				}
			} else {
				throw new CapStoreException("Account ID does not exist.");
			}
		} catch (Exception e) {
			throw new CapStoreException("Please enter valid details :-(");
		}
	}

	@Override
	public long findByCustomerContactNo(String customerContactNo) {
		return customerDao.findByContactNo(customerContactNo).getCustomerId();
	}

	@Autowired
	IMerchantDao merchantDao;

	@Override
	public boolean changePasswordMerchant(long merchantId, String oldPassword, String newPassword)
			throws CapStoreException {
		try {
			Optional<Merchant> optional = merchantDao.findById(merchantId);
			if (optional.isPresent()) {
				if (Decryption.decrypt(optional.get().getMerchantPassword()).contains(oldPassword)) {
					Merchant merchant = optional.get();
					merchant.setMerchantId(optional.get().getMerchantId());
					merchant.setMerchantName(optional.get().getMerchantName());
					merchant.setMerchantPassword(Encryption.encrypt(newPassword));
					merchant.setMerchantContactNo(optional.get().getMerchantContactNo());
					merchant.setMerchantGSTNo(optional.get().getMerchantGSTNo());
					merchant.setMerchantCompanyName(optional.get().getMerchantCompanyName());
					merchant.setMerchantQuestion(optional.get().getMerchantQuestion());
					merchant.setMerchantAnswer(optional.get().getMerchantAnswer());
					merchant.setMerchantStatus(Status.ACTIVE);
					merchantDao.save(merchant);
					return true;
				} else {
					throw new CapStoreException("Please enter correct Old Password.");
				}
			} else {
				throw new CapStoreException("Account does not Exist.");
			}

		} catch (Exception e) {
			throw new CapStoreException("Please enter valid details :-(");

		}

	}

	@Override
	public boolean forgetPassword(long merchantId, int merchantQuestion, String merchantAnswer, String newPassword
			) throws CapStoreException {
		try {
			Optional<Merchant> optional = merchantDao.findById(merchantId);
			if (optional.isPresent()) {
				if (optional.get().getMerchantAnswer().contains(merchantAnswer)
						&& optional.get().getMerchantQuestion() == merchantQuestion) {
					Merchant merchant = optional.get();
					merchant.setMerchantPassword(Encryption.encrypt(newPassword));
					merchantDao.save(merchant);
					return true;
				} else {
					throw new CapStoreException("Please enter the correct answer for that question.");
				}
			} else {
				throw new CapStoreException("Account ID does not exist.");
			}

		} catch (Exception e) {
			throw new CapStoreException("Please enter valid details :-(");
		}
	}

	@Override
	public long findByMerchantContactNo(String merchantContactNo) {
		return merchantDao.findByContactNo(merchantContactNo).getMerchantId();
	}
}
