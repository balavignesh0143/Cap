package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.beans.Merchant;

public interface IGetAccounts {
	List<Admin> getAdminsAccounts();
	
	List<Customer> getCustomerAccounts();
	
	List<Merchant> getMerchantAccounts();
}
