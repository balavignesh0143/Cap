package com.cg.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capstore.bean.Address;

public interface CapstoreDaoAdmin extends JpaRepository<Address, String> {

}
