package selenium;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FreeCRSSignup {

	private static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		File file = new File("C:/Users/ar43/Desktop/testingjarsanddrivers/chromedriver/chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://freecrm.com");
//		driver.findElement(By.xpath("/html/body/div[1]/header/div/nav/div[2]/div/div[2]/ul/li[1]/a")).click();
		driver.findElement(By.xpath("/html/body/div[1]/header/div/nav/div[2]/div/div[2]/ul/a/span[2]")).click();
//		driver.findElement(By.partialLinkText("Your")).click();
		driver.findElement(By.xpath("//*[@id=\"ui\"]/div/div/form/div/div[1]/div/input")).sendKeys("aswin@1997");
		driver.findElement(By.name("password")).sendKeys("iamlegend");
		driver.findElement(By.xpath("//*[@id=\"ui\"]/div/div/form/div/div[3]")).submit();
		Thread.sleep(5000);
	}

}
