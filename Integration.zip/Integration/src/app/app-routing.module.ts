import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { RegisterComponent } from './register/register.component';
import { RegisterCustomerComponent } from './register-customer/register-customer.component';
import { RegisterMerchantComponent } from './register-merchant/register-merchant.component';
import { GuardGuard } from './authguard/guard.guard';
import { ForgetpasswordComponent } from './forgetpassword/forgetpassword.component';
import { HomepageComponent } from './homepage/homepage.component';
import { DashboardComponent } from './dashboard/dashboard.component';

const routes: Routes = [
  { path: '', redirectTo: 'app-homepage', pathMatch: 'full'},
  { path: 'addemployee', component: AddEmployeeComponent,canActivate:[GuardGuard]},
  { path: 'login', component: LoginComponent },
  { path: 'app-register', component: RegisterComponent },
  { path: 'app-register/app-register-customer', component: RegisterCustomerComponent },
  { path: 'app-register/app-register-merchant', component: RegisterMerchantComponent },
  { path: 'login/app-forgetpassword', component: ForgetpasswordComponent },
  { path: 'logout', component: LogoutComponent,canActivate:[GuardGuard] },
  { path: 'app-homepage', component: HomepageComponent},
  { path: 'dashboard', component: DashboardComponent,canActivate:[GuardGuard]},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
