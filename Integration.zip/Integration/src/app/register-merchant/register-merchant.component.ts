import { Component, OnInit } from '@angular/core';
import { Merchant } from '../beans/Merchant';
import { RegisterService } from '../service/register.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-merchant',
  templateUrl: './register-merchant.component.html',
  styleUrls: ['./register-merchant.component.css']
})
export class RegisterMerchantComponent implements OnInit {
  registerService: RegisterService;
  router: Router;

  constructor(registerService: RegisterService, private spinner: NgxSpinnerService, router: Router) {
    this.registerService = registerService;
    this.router = router;
  }

  registerMerchant(data: Merchant) {
    var merchant = this.registerService.registerMerchant(data)
    merchant.subscribe((data) => {
      alert("Register Successfully :-)\nYour Account Id is : " + data.merchantId)
      this.router.navigate(['login'])

    })
  }

  ngOnInit() {
    this.spinner.show();
    setTimeout(() => {
      this.spinner.hide();
    }, 3000);
  }
}
