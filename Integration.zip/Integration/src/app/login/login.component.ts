import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { LoginService } from '../service/login.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userId = ''
  userPassword = ''
  invalidLogin = false
  login: LoginService;
  router: Router;

  constructor(router: Router, private auth: AuthenticationService, login: LoginService, private spinner: NgxSpinnerService) {
    this.login = login;
    this.router = router;
  }

  ngOnInit() {
    this.spinner.show();
    setTimeout(() => {
      this.spinner.hide();
    }, 1000);
  }


  checkLogin(data: any) {
    var encryptuserId = (userId): number => {
      var genereatedId = parseInt(userId) - 500000;
      return genereatedId;
    }


    if(this.login.loginAccount(data)){
      let encryptUserId = encryptuserId(data.userId);
      this.auth.sendToken(encryptUserId.toString());
    }


  }

}