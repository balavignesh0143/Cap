import { Injectable } from '@angular/core';
import { Customer } from '../beans/Customer';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Merchant } from '../beans/Merchant';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {
  http:HttpClient;
  constructor(http: HttpClient) {
    this.http = http;
  }

  registerCustomer(data:Customer):Observable<any>{
    var customer = {
      "customerName":data.customerName,
      "customerPassword":data.customerPassword,
      "customerContactNo":data.customerContactNo,
      "customerAddress":data.customerAddress,
      "customerQuestion":data.customerQuestion,
      "customerAnswer":data.customerAnswer
    }

    return this.http.post("http://localhost:6798/customer/create", customer);

  }

  registerMerchant(data:Merchant):Observable<any>{
    var merchant = {
      "merchantName":data.merchantName,
      "merchantPassword":data.merchantPassword,
      "merchantContactNo":data.merchantContactNo,
      "merchantGSTNo":data.merchantGSTNo,
      "merchantCompanyName":data.merchantCompanyName,
      "merchantQuestion":data.merchantQuestion,
      "merchantAnswer":data.merchantAnswer
    }
    console.log(merchant)

    return this.http.post("http://localhost:6798/merchant/create", merchant);

  }

}
