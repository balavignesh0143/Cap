import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Admin } from '../beans/Admin';
import { Customer } from '../beans/Customer';
import { Merchant } from '../beans/Merchant';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  http: HttpClient;
  router:Router;
  admins: Admin[] = [];
  customers: Customer[] = [];
  merchants: Merchant[] = [];
  flagCustomer:boolean=false;
  flagMerchant:boolean=false;
  flagAdmin:boolean=false;


  constructor(http: HttpClient,router:Router) {
    this.http = http;
    this.router=router;
    this.fetchAdmin();
    this.fetchCustomer();
    this.fetchMerchant();
    console.log(this.admins);
    console.log(this.customers);
    console.log(this.merchants);
  }

  fetchAdmin() {
    var admins = this.http.get('http://localhost:6798/admin/getAccounts')
    admins.subscribe((data) => {
      this.convertAdmin(data);
    })
  }

  convertAdmin(data: any) {
    for (let o of data) {
      let e = new Admin(o.adminId, o.adminName, o.adminPassword);
      this.admins.push(e);
    }
  }

  fetchCustomer() {
    var customers = this.http.get('http://localhost:6798/customer/getAccounts')
    customers.subscribe((data) => {
      this.convertCustomer(data);
    })
  }

  convertCustomer(data: any) {
    for (let o of data) {
      let e = new Customer(o.customerId, o.customerName, o.customerPassword,
        o.customerContactNo, o.customerAddress, o.customerStatus,
        o.customerQuestion, o.customerAnswer);
      this.customers.push(e);
    }
  }

  fetchMerchant() {
    var merchant = this.http.get('http://localhost:6798/merchant/getAccounts')
    merchant.subscribe((data) => {
      this.convertMerchant(data);
    })
  }

  convertMerchant(data: any) {
    for (let o of data) {
      let e = new Merchant(o.merchantId, o.merchantName, o.merchantPassword,
        o.merchantContactNo, o.merchantGSTNo, o.merchantCompanyName,
        o.merchantStatus, o.merchantDiscount, o.merchantQuestion, o.merchantAnswer);
      this.merchants.push(e);
    }
  }

  forgetPassword(data: any){

        this.http.put('http://localhost:6798/customer/forgetPassword/'
        +data.userId
        +"/"+data.userQuestion
        +"/"+data.userAnswer
        +"/"+data.userPassword
        ,null).subscribe((data)=>
        {
            alert("Changed Successfully (C) :-)")
            this.router.navigate(['/login'])
        },(errorC)=>
        {
          // console.log(errorC.error)
          // alert(errorC.error.message)
          this.http.put('http://localhost:6798/merchant/forgetPassword/'
          +data.userId
          +"/"+data.userQuestion
          +"/"+data.userAnswer
          +"/"+data.userPassword
          ,null).subscribe((data)=>
          {
            alert("Changed Successfully (M) :-)")
            this.router.navigate(['/login'])
          },(errorM)=>
          {
            console.log(errorM.error.message)
            alert(errorM.error.message)
          })
        })
    }


    changePassword(data:any){
      this.http.put('http://localhost:6798/customer/changePassword/'
      +data.userId
      +"/"+data.oldPassword
      +"/"+data.newPassword
      ,null).subscribe((data)=>
      {
          alert("Changed Successfully (C) :-)")
          this.router.navigate(['/login'])
      },(errorC)=>
      {
        // console.log(errorC.error)
        // alert(errorC.error.message)
        this.http.put('http://localhost:6798/merchant/changePassword/'
        +data.userId
        +"/"+data.oldPassword
        +"/"+data.newPassword
        ,null).subscribe((data)=>
        {
          alert("Changed Successfully (M) :-)")
          this.router.navigate(['/login'])
        },(errorM)=>
        {
          console.log(errorM.error.message)
          alert(errorM.error.message)
        })
      })

    }



  loginAccount(data: any):boolean {
    // this.fetchAdmin();
    // this.fetchCustomer();
    // this.fetchMerchant();

    for (let a of this.admins) {
      if (a.adminId === data.userId && a.adminPassword === data.userPassword) {
        alert("You are Admin :-)\n Your Account Id is : "+a.adminId)
        this.flagAdmin=true;
        this.router.navigate(['dashboard']);
        return true;
        // return a.adminId;
      } else {
        for (let c of this.customers) {
          if (c.customerId == data.userId && c.customerPassword == data.userPassword) {
            alert("You are Customer :-)\n Your Account Id is : "+c.customerId)
            this.flagCustomer=true;
            this.router.navigate(['dashboard']);
            return true;
            // return c.customerId;
          } else {
            for (let m of this.merchants) {
              if (m.merchantId == data.userId && m.merchantPassword == data.userPassword) {
                alert("You are Merchant :-)")
                this.flagMerchant=true;
                this.router.navigate(['dashboard']);
                return true;
                // return m.merchantId;
              }
            }
          }
        }
      }
    }

    if(this.flagAdmin == false || this.flagCustomer==false || this.flagMerchant==false){
     alert("Invalid Credantials")
    }else{
      alert("Login Successfull :-)")
    }

  }
}
