import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bottom-bar-section',
  templateUrl: 'bottom-bar-section.component.html',
  styleUrls: ['bottom-bar-section.component.css']
})
export class BottomBarSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
