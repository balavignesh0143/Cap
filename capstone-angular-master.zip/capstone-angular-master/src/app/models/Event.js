"use strict";
var Event = (function () {
    function Event() {
    }
    return Event;
}());
exports.Event = Event;
