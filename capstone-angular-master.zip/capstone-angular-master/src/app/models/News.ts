export class News {
  id: number;
  title: string;
  content: string;
  cover_image_url: string;
  url: string;
  timestamp: number;

}
