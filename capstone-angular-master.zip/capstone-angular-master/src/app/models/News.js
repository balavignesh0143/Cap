"use strict";
var News = (function () {
    function News() {
    }
    return News;
}());
exports.News = News;
