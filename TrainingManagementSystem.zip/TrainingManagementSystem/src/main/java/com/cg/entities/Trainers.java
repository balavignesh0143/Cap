package com.cg.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "trainee1")
public class Trainers {
	@Id
	//@NotNull(message="ID Not Null")
	private int id;
	@NotBlank(message="Name Not Null")
	//@Size(min=3,max=20)
	//@Min(value=3)
	//@Max(value=20)
	private String name;
	@Max(value=50000,message="FEES Max Value should not exceed 50,000/-")
	private int fees;
	//@Size(min=10,max=999,message="DURATION numbers of hours should be 2 to 3 digits")
	@Min(value=10,message="DURATION numbers of hours should be 2 to 3 digits")
	@Max(value=999,message="DURATION numbers of hours should be 2 to 3 digits")
	private int duration;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getFees() {
		return fees;
	}

	public void setFees(int fees) {
		this.fees = fees;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

}
