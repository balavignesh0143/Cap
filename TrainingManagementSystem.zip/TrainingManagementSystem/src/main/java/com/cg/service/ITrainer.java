package com.cg.service;

import java.util.List;

import com.cg.entities.Trainers;

public interface ITrainer {

	List<Trainers> findAll();

	Trainers findTrainersById(int id);

	Trainers addTrainers(Trainers tran);

	void deleteTrainee(int id);

}
