package com.capgemini.capstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "invoiceMaster")
public class InvoiceEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(length = 20)
	private long customerId;
	@Column(length = 20)
	private long invoiceId;
	@Column(length = 10)
	private int adminDiscount;
	@Column(length = 10)
	private double finalAmount;

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public long getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(long invoiceId) {
		this.invoiceId = invoiceId;
	}

	public double getAdminDiscount() {
		return adminDiscount;
	}

	public void setAdminDiscount(int adminDiscount) {
		this.adminDiscount = adminDiscount;
	}

	public double getFinalAmount() {
		return finalAmount;
	}

	public void setFinalAmount(double finalAmount) {
		this.finalAmount = finalAmount;
	}

	public InvoiceEntity() {
		super();

	}

	public InvoiceEntity(long customerId, long invoiceId, int adminDiscount, double finalAmount) {
		super();
		this.customerId = customerId;
		this.invoiceId = invoiceId;
		this.adminDiscount = adminDiscount;
		this.finalAmount = finalAmount;
	}

	@Override
	public String toString() {
		return "InvoiceMaster [customerId=" + customerId + ", invoiceId=" + invoiceId + ", adminDiscount="
				+ adminDiscount + ", finalAmount=" + finalAmount + "]";
	}

}