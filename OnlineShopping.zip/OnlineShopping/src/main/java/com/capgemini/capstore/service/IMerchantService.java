package com.capgemini.capstore.service;

import com.capgemini.capstore.entities.MerchantMasterEntity;

public interface IMerchantService {

	MerchantMasterEntity createAccount(MerchantMasterEntity merchant);

	MerchantMasterEntity viewById(long merchantId);

}
