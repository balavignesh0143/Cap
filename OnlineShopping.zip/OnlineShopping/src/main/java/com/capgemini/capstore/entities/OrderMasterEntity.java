package com.capgemini.capstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class OrderMasterEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(length = 20)
	private long orderId;
	@Column(length = 20)
	private long invoiceId;
	@Column(length = 20)
	private long productId;
	private double discountTotal;
	private int quantity;
	private double totalAmount;
	@Column(length = 50)
	private String status;

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public long getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(long invoiceId) {
		this.invoiceId = invoiceId;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public double getDiscountTotal() {
		return discountTotal;
	}

	public void setDiscountTotal(double discountTotal) {
		this.discountTotal = discountTotal;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public OrderMasterEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderMasterEntity(long orderId, long invoiceId, long productId, double discountTotal, int quantity,
			double totalAmount, String status) {
		super();
		this.orderId = orderId;
		this.invoiceId = invoiceId;
		this.productId = productId;
		this.discountTotal = discountTotal;
		this.quantity = quantity;
		this.totalAmount = totalAmount;
		this.status = status;
	}

	@Override
	public String toString() {
		return "OrderMaster [orderId=" + orderId + ", invoiceId=" + invoiceId + ", productId=" + productId
				+ ", discountTotal=" + discountTotal + ", quantity=" + quantity + ", totalAmount=" + totalAmount
				+ ", status=" + status + "]";
	}

}