package com.capgemini.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.entities.MerchantMasterEntity;

public interface IMerchantDao extends JpaRepository<MerchantMasterEntity, Long> {

}
