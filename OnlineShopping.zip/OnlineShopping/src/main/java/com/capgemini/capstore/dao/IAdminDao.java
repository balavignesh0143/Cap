package com.capgemini.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.entities.AdminMasterEntity;

public interface IAdminDao extends JpaRepository<AdminMasterEntity, Long>{

}
