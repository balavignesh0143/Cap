package com.capgemini.capstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "statusMaster")
public class StatusMasterEntity {

	@Column(length = 20)
	private long orderId;
	@Column(length = 50)
	private String status;

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public StatusMasterEntity() {
		super();
	}

	/**
	 * @param orderId
	 * @param status
	 */
	public StatusMasterEntity(long orderId, String status) {
		super();
		this.orderId = orderId;
		this.status = status;
	}

	@Override
	public String toString() {
		return "StatusMaster [orderId=" + orderId + ", status=" + status + "]";
	}

}