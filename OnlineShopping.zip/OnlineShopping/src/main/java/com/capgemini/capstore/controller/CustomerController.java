package com.capgemini.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.entities.CustomerMasterEntity;
import com.capgemini.capstore.service.ICustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	ICustomerService customerservice;
	
	@PostMapping(value="/create")
	public CustomerMasterEntity createAccount(@RequestBody CustomerMasterEntity customer)
	{
		return customerservice.createAccount(customer);
	}
	
	@GetMapping(value="/view/{customerId}")
	public CustomerMasterEntity viewById(@PathVariable long customerId)
	{
		return customerservice.viewById(customerId);
	}
	
}
