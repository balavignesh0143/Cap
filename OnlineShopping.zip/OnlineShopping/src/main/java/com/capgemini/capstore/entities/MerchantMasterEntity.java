package com.capgemini.capstore.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "merchantMaster")
public class MerchantMasterEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceId")
	@SequenceGenerator(name = "sequenceId", initialValue = 222222, sequenceName = "merchantId") // to be created
	@Column(length = 20)
	private long merchantId;
	@Column(length = 20)
	private String merchantName;
	@Column(length = 20)
	private String merchantPassword;
	@Column(length = 20)
	private String merchantContactNo;
	@Column(name = "merchant_GST_No", length = 20)
	private String merchantGSTNo;
	@Column(length = 20)
	private String merchantCompanyName;
	@Column(length = 20)
	private String merchantStatus;
	@Column(length = 20)
	private long merchantDiscount;

	/**
	 * @return the merchantId
	 */
	public long getMerchantId() {
		return merchantId;
	}

	/**
	 * @param merchantId
	 *            the merchantId to set
	 */
	public void setMerchantId(long merchantId) {
		this.merchantId = merchantId;
	}

	/**
	 * @return the merchantName
	 */
	public String getMerchantName() {
		return merchantName;
	}

	/**
	 * @param merchantName
	 *            the merchantName to set
	 */
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	/**
	 * @return the merchantPassword
	 */
	public String getMerchantPassword() {
		return merchantPassword;
	}

	/**
	 * @param merchantPassword
	 *            the merchantPassword to set
	 */
	public void setMerchantPassword(String merchantPassword) {
		this.merchantPassword = merchantPassword;
	}

	/**
	 * @return the merchantContactNo
	 */
	public String getMerchantContactNo() {
		return merchantContactNo;
	}

	/**
	 * @param merchantContactNo
	 *            the merchantContactNo to set
	 */
	public void setMerchantContactNo(String merchantContactNo) {
		this.merchantContactNo = merchantContactNo;
	}

	/**
	 * @return the merchantGSTNo
	 */
	public String getMerchantGSTNo() {
		return merchantGSTNo;
	}

	/**
	 * @param merchantGSTNo
	 *            the merchantGSTNo to set
	 */
	public void setMerchantGSTNo(String merchantGSTNo) {
		this.merchantGSTNo = merchantGSTNo;
	}

	/**
	 * @return the merchantCompanyName
	 */
	public String getMerchantCompanyName() {
		return merchantCompanyName;
	}

	/**
	 * @param merchantCompanyName
	 *            the merchantCompanyName to set
	 */
	public void setMerchantCompanyName(String merchantCompanyName) {
		this.merchantCompanyName = merchantCompanyName;
	}

	/**
	 * @return the merchantStatus
	 */
	public String getMerchantStatus() {
		return merchantStatus;
	}

	/**
	 * @param merchantStatus
	 *            the merchantStatus to set
	 */
	public void setMerchantStatus(String merchantStatus) {
		this.merchantStatus = merchantStatus;
	}

	/**
	 * @return the merchantDiscount
	 */
	public long getMerchantDiscount() {
		return merchantDiscount;
	}

	/**
	 * @param merchantDiscount
	 *            the merchantDiscount to set
	 */
	public void setMerchantDiscount(long merchantDiscount) {
		this.merchantDiscount = merchantDiscount;
	}

	/**
	 * @param merchantId
	 * @param merchantName
	 * @param merchantPassword
	 * @param merchantContactNo
	 * @param merchantGSTNo
	 * @param merchantCompanyName
	 * @param merchantStatus
	 * @param merchantDiscount
	 */
	public MerchantMasterEntity(long merchantId, String merchantName, String merchantPassword, String merchantContactNo,
			String merchantGSTNo, String merchantCompanyName, String merchantStatus, long merchantDiscount) {
		super();
		this.merchantId = merchantId;
		this.merchantName = merchantName;
		this.merchantPassword = merchantPassword;
		this.merchantContactNo = merchantContactNo;
		this.merchantGSTNo = merchantGSTNo;
		this.merchantCompanyName = merchantCompanyName;
		this.merchantStatus = merchantStatus;
		this.merchantDiscount = merchantDiscount;
	}

	/**
	 * 
	 */
	public MerchantMasterEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MerchantMasterEntity [merchantId=" + merchantId + ", merchantName=" + merchantName
				+ ", merchantPassword=" + merchantPassword + ", merchantContactNo=" + merchantContactNo
				+ ", merchantGSTNo=" + merchantGSTNo + ", merchantCompanyName=" + merchantCompanyName
				+ ", merchantStatus=" + merchantStatus + ", merchantDiscount=" + merchantDiscount + "]";
	}

}
