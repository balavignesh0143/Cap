package com.bwa.validation;

import java.util.regex.Pattern;

import com.bwa.dao.BankDAOImpl;
import com.bwa.exception.BankUserInputException;

public class BankUserIOValidation {

	static BankDAOImpl bankDAOImpl=new BankDAOImpl();
	
	public static boolean checkName(String name) throws BankUserInputException {
		  if (Pattern.matches("([A-Z])([a-z])*",name))
	           return true;
	       else
	           return false;
	}

	public static boolean checkPIN(int pin) throws BankUserInputException {
		try {
			String g=Integer.toString(pin);
			if (g.matches("[0-9]+") && g.length() == 4) {
				return true;
			} else {
				throw new BankUserInputException("Invalid PIN");

			}
		} catch (BankUserInputException e) {
			return false;
		}
	}

	public static boolean checkPhoneNumber(String number) throws BankUserInputException {
		try {
			if (number.matches("[0-9]+") && number.length() == 10) {
				return true;
			} else {
				throw new BankUserInputException("Invalid Phonenumber");
			}
		} catch (BankUserInputException e) {
			return false;
		}
	}
	
	public static boolean checkAccNo(int accountNumber) throws BankUserInputException {
		try {
			if (bankDAOImpl.checkAccountNumber(accountNumber))
				return true;
			else
				throw new BankUserInputException("Invalid Account Number");
		} catch (BankUserInputException e) {
			return false;

		}

	}
}