package com.bwa.exception;

@SuppressWarnings("serial")

public class BankUserInputException extends Exception {
	String s1;

	public BankUserInputException(String s) {
		s1 = s;

	}

	public String toString() {
		return (s1);
	}
}
